package com.example.lesson3_4;



public interface onClick {
        void onClick(Model model);
    }

